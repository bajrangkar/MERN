import React, { useEffect, useState } from "react";
import axios from "axios";
import UserForm from "./components/UserForm";
import UserList from "./components/UserList";

function App() {

  const [users, setUsers] = useState([]);

  const fetchUsers = async () => {
    const res = await axios.get("http://localhost:3000/users");
    setUsers(res.data);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  return (
    <div>
      <h1>MongoDB CRUD App</h1>

      <UserForm fetchUsers={fetchUsers} />

      <UserList users={users} fetchUsers={fetchUsers} />

    </div>
  );
}

export default App;