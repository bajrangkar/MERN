import React, { useState } from "react";
import axios from "axios";

function UserForm({ fetchUsers }) {
  const [user, setUser] = useState({
    name: "",
    email: "",
    age: ""
  });

  const handleChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    await axios.post("http://localhost:3000/users", user);

    setUser({ name: "", email: "", age: "" });

    fetchUsers();
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        name="name"
        placeholder="Name"
        value={user.name}
        onChange={handleChange}
      />

      <input
        name="email"
        placeholder="Email"
        value={user.email}
        onChange={handleChange}
      />

      <input
        name="age"
        placeholder="Age"
        value={user.age}
        onChange={handleChange}
      />

      <button type="submit">Add User</button>
    </form>
  );
}

export default UserForm;