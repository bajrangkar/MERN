import React from "react";
import axios from "axios";

function UserList({ users, fetchUsers }) {

  const deleteUser = async (id) => {
    await axios.delete(`http://localhost:3000/users/${id}`);
    fetchUsers();
  };

  return (
    <div>
      <h2>User List</h2>

      {users.map((user) => (
        <div key={user._id}>
          <p>{user.name} - {user.email} - {user.age}</p>

          <button onClick={() => deleteUser(user._id)}>
            Delete
          </button>
        </div>
      ))}

    </div>
  );
}

export default UserList;